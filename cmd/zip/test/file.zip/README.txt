This zip file is used for go test DO NOT MODIFY!
